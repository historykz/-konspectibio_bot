"""Middleware that auto-links username-only students to their tg_id."""
import logging
from typing import Any, Awaitable, Callable, Dict

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject

from bot.database import repo

logger = logging.getLogger(__name__)


class AccessMiddleware(BaseMiddleware):
    """Auto-link username → tg_id when a pre-added student first writes the bot."""

    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        user = None
        if isinstance(event, Message):
            user = event.from_user
        elif isinstance(event, CallbackQuery):
            user = event.from_user

        if user and user.username:
            try:
                await repo.link_student_tg_id(user.username, user.id)
            except Exception:
                logger.exception("Failed to link username -> tg_id")

        return await handler(event, data)
