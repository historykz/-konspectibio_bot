"""Parse free-form admin input into student identities."""
from dataclasses import dataclass
from typing import List, Optional
import re

USERNAME_RE = re.compile(r"@?([A-Za-z][A-Za-z0-9_]{4,31})")
ID_RE = re.compile(r"^\d{5,15}$")


@dataclass
class ParsedIdentity:
    raw: str
    tg_id: Optional[int] = None
    username: Optional[str] = None
    error: Optional[str] = None


def parse_identity(token: str) -> ParsedIdentity:
    """Parse a single token as either a numeric Telegram ID or a @username."""
    token = token.strip().rstrip(",;")
    if not token:
        return ParsedIdentity(raw=token, error="пусто")

    if ID_RE.match(token):
        return ParsedIdentity(raw=token, tg_id=int(token))

    if token.startswith("@"):
        m = USERNAME_RE.fullmatch(token)
        if m:
            return ParsedIdentity(raw=token, username=m.group(1))
        return ParsedIdentity(raw=token, error="неверный формат username")

    # bare alphanumeric: treat as username if it looks like one
    m = USERNAME_RE.fullmatch(token)
    if m:
        return ParsedIdentity(raw=token, username=m.group(1))

    return ParsedIdentity(raw=token, error="не похоже на ID или @username")


def parse_bulk(text: str) -> List[ParsedIdentity]:
    """Split admin input by newlines/commas/spaces and parse each piece."""
    tokens = re.split(r"[\s,;]+", text.strip())
    return [parse_identity(t) for t in tokens if t]
