"""Async PostgreSQL connection pool with schema migrations."""
import logging
from typing import Optional

import asyncpg

from bot.config import settings

logger = logging.getLogger(__name__)

_pool: Optional[asyncpg.Pool] = None


SCHEMA = """
CREATE TABLE IF NOT EXISTS students (
    id           BIGSERIAL PRIMARY KEY,
    tg_id        BIGINT       UNIQUE,
    username     TEXT         UNIQUE,
    full_name    TEXT,
    added_by     BIGINT       NOT NULL,
    added_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    CONSTRAINT students_identity_chk CHECK (tg_id IS NOT NULL OR username IS NOT NULL)
);

CREATE INDEX IF NOT EXISTS idx_students_username ON students (LOWER(username));
CREATE INDEX IF NOT EXISTS idx_students_tg_id    ON students (tg_id);

CREATE TABLE IF NOT EXISTS notes (
    serial       INTEGER      PRIMARY KEY,
    topic        TEXT         NOT NULL,
    file_id      TEXT         NOT NULL,
    file_unique  TEXT,
    file_name    TEXT,
    file_size    BIGINT,
    added_by     BIGINT       NOT NULL,
    added_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_notes_topic ON notes (LOWER(topic));
"""


async def init_db() -> None:
    global _pool
    # Railway gives postgres:// — asyncpg wants postgresql://
    dsn = settings.DATABASE_URL.replace("postgres://", "postgresql://", 1)
    _pool = await asyncpg.create_pool(
        dsn=dsn,
        min_size=1,
        max_size=10,
        command_timeout=30,
    )
    async with _pool.acquire() as conn:
        await conn.execute(SCHEMA)
    logger.info("Database initialized")


async def close_db() -> None:
    global _pool
    if _pool is not None:
        await _pool.close()
        _pool = None
        logger.info("Database pool closed")


def pool() -> asyncpg.Pool:
    if _pool is None:
        raise RuntimeError("Database not initialized. Call init_db() first.")
    return _pool
