"""Data access layer: students and notes."""
from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional

from bot.database.db import pool


# ─────────────────────────── Models ───────────────────────────


@dataclass
class Student:
    id: int
    tg_id: Optional[int]
    username: Optional[str]
    full_name: Optional[str]
    added_by: int
    added_at: datetime


@dataclass
class Note:
    serial: int
    topic: str
    file_id: str
    file_unique: Optional[str]
    file_name: Optional[str]
    file_size: Optional[int]
    added_by: int
    added_at: datetime
    updated_at: datetime


# ─────────────────────────── Students ───────────────────────────


def _normalize_username(username: Optional[str]) -> Optional[str]:
    if not username:
        return None
    return username.lstrip("@").lower().strip() or None


async def add_student(
    *,
    tg_id: Optional[int],
    username: Optional[str],
    full_name: Optional[str],
    added_by: int,
) -> tuple[bool, str]:
    """Returns (created, message). created=False if already exists."""
    username = _normalize_username(username)
    if tg_id is None and username is None:
        return False, "Нужен либо ID, либо @username"

    async with pool().acquire() as conn:
        # Conflict check: same tg_id OR same username
        existing = await conn.fetchrow(
            """
            SELECT id, tg_id, username FROM students
            WHERE (tg_id = $1 AND $1 IS NOT NULL)
               OR (username = $2 AND $2 IS NOT NULL)
            LIMIT 1
            """,
            tg_id, username,
        )
        if existing:
            return False, "уже добавлен"

        await conn.execute(
            """
            INSERT INTO students (tg_id, username, full_name, added_by)
            VALUES ($1, $2, $3, $4)
            """,
            tg_id, username, full_name, added_by,
        )
        return True, "добавлен"


async def remove_student_by_tg_id(tg_id: int) -> bool:
    async with pool().acquire() as conn:
        result = await conn.execute("DELETE FROM students WHERE tg_id = $1", tg_id)
        return result.endswith(" 1")


async def remove_student_by_username(username: str) -> bool:
    username = _normalize_username(username)
    if not username:
        return False
    async with pool().acquire() as conn:
        result = await conn.execute("DELETE FROM students WHERE username = $1", username)
        return result.endswith(" 1")


async def find_student(*, tg_id: Optional[int] = None,
                       username: Optional[str] = None) -> Optional[Student]:
    username = _normalize_username(username)
    async with pool().acquire() as conn:
        row = await conn.fetchrow(
            """
            SELECT * FROM students
            WHERE (tg_id = $1 AND $1 IS NOT NULL)
               OR (username = $2 AND $2 IS NOT NULL)
            LIMIT 1
            """,
            tg_id, username,
        )
        return Student(**dict(row)) if row else None


async def link_student_tg_id(username: str, tg_id: int) -> bool:
    """When a student first writes /start, attach their tg_id to the username record."""
    username = _normalize_username(username)
    if not username:
        return False
    async with pool().acquire() as conn:
        # Don't overwrite if already linked to a different account
        result = await conn.execute(
            """
            UPDATE students
            SET tg_id = $1
            WHERE username = $2 AND (tg_id IS NULL OR tg_id = $1)
            """,
            tg_id, username,
        )
        return result.endswith(" 1")


async def is_student(*, tg_id: int, username: Optional[str] = None) -> bool:
    username = _normalize_username(username)
    async with pool().acquire() as conn:
        row = await conn.fetchrow(
            """
            SELECT 1 FROM students
            WHERE tg_id = $1 OR (username = $2 AND $2 IS NOT NULL)
            LIMIT 1
            """,
            tg_id, username,
        )
        return row is not None


async def list_students() -> List[Student]:
    async with pool().acquire() as conn:
        rows = await conn.fetch("SELECT * FROM students ORDER BY added_at DESC")
        return [Student(**dict(r)) for r in rows]


async def count_students() -> int:
    async with pool().acquire() as conn:
        return await conn.fetchval("SELECT COUNT(*) FROM students")


# ─────────────────────────── Notes ───────────────────────────


async def upsert_note(
    *,
    serial: int,
    topic: str,
    file_id: str,
    file_unique: Optional[str],
    file_name: Optional[str],
    file_size: Optional[int],
    added_by: int,
) -> str:
    """Insert or replace a note. Returns 'created' or 'replaced'."""
    async with pool().acquire() as conn:
        existed = await conn.fetchval("SELECT 1 FROM notes WHERE serial = $1", serial)
        await conn.execute(
            """
            INSERT INTO notes (serial, topic, file_id, file_unique,
                               file_name, file_size, added_by)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            ON CONFLICT (serial) DO UPDATE SET
                topic       = EXCLUDED.topic,
                file_id     = EXCLUDED.file_id,
                file_unique = EXCLUDED.file_unique,
                file_name   = EXCLUDED.file_name,
                file_size   = EXCLUDED.file_size,
                added_by    = EXCLUDED.added_by,
                updated_at  = NOW()
            """,
            serial, topic, file_id, file_unique, file_name, file_size, added_by,
        )
        return "replaced" if existed else "created"


async def get_note(serial: int) -> Optional[Note]:
    async with pool().acquire() as conn:
        row = await conn.fetchrow("SELECT * FROM notes WHERE serial = $1", serial)
        return Note(**dict(row)) if row else None


async def delete_note(serial: int) -> bool:
    async with pool().acquire() as conn:
        result = await conn.execute("DELETE FROM notes WHERE serial = $1", serial)
        return result.endswith(" 1")


async def list_notes(limit: int = 200) -> List[Note]:
    async with pool().acquire() as conn:
        rows = await conn.fetch(
            "SELECT * FROM notes ORDER BY serial ASC LIMIT $1", limit
        )
        return [Note(**dict(r)) for r in rows]


async def count_notes() -> int:
    async with pool().acquire() as conn:
        return await conn.fetchval("SELECT COUNT(*) FROM notes")
