"""Handlers available to everyone: /start, /help."""
from aiogram import Router, F
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

from bot.config import settings
from bot.database import repo

router = Router(name="common")


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext) -> None:
    await state.clear()
    user = message.from_user
    if settings.is_admin(user.id):
        await message.answer(
            "👋 Привет, админ!\n\n"
            "<b>Команды:</b>\n"
            "/addnote — добавить или заменить конспект\n"
            "/delnote — удалить конспект\n"
            "/notes — список всех конспектов\n"
            "/addstudent — добавить ученика(ов)\n"
            "/delstudent — удалить ученика\n"
            "/students — список учеников\n"
            "/stats — статистика\n"
            "/cancel — отменить текущее действие"
        )
        return

    if await repo.is_student(tg_id=user.id, username=user.username):
        count = await repo.count_notes()
        await message.answer(
            f"👋 Привет, {user.first_name}!\n\n"
            f"Отправь номер конспекта (например <b>29</b>) — "
            f"и я пришлю его тебе.\n\n"
            f"Сейчас доступно конспектов: <b>{count}</b>"
        )
    else:
        await message.answer(
            "🔒 У вас нет доступа к боту.\n\n"
            "Обратитесь к преподавателю, чтобы он добавил вас в список учеников."
        )


@router.message(Command("help"))
async def cmd_help(message: Message) -> None:
    user = message.from_user
    if settings.is_admin(user.id):
        await message.answer(
            "<b>Админские команды:</b>\n"
            "• /addnote — добавить/заменить конспект (мастер из 3 шагов)\n"
            "• /delnote — удалить конспект по номеру\n"
            "• /notes — список всех конспектов\n"
            "• /addstudent — добавить ученика(ов). Можно массово: "
            "пришли список @username или ID через пробел/запятую/новую строку\n"
            "• /delstudent — удалить ученика\n"
            "• /students — список учеников\n"
            "• /stats — общая статистика\n"
            "• /cancel — отменить текущее действие"
        )
    else:
        await message.answer(
            "Просто отправь номер конспекта числом — например <b>29</b>."
        )


@router.message(Command("cancel"))
async def cmd_cancel(message: Message, state: FSMContext) -> None:
    current = await state.get_state()
    if current is None:
        await message.answer("Нечего отменять.")
        return
    await state.clear()
    await message.answer("❌ Отменено.")


@router.message(F.text)
async def fallback(message: Message) -> None:
    """Anything that wasn't caught above — likely an invalid serial or unknown command."""
    user = message.from_user
    if settings.is_admin(user.id):
        await message.answer(
            "Не понял команду. Нажми /help, чтобы увидеть список."
        )
        return

    if not await repo.is_student(tg_id=user.id, username=user.username):
        await message.answer("🔒 У вас нет доступа.")
        return

    await message.answer(
        "Отправь <b>номер конспекта</b> числом (например, <code>29</code>)."
    )
