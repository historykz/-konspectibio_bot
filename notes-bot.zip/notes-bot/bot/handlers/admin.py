"""Admin handlers: manage notes and students."""
import html
import logging

from aiogram import Router, F
from aiogram.filters import Command, CommandObject, Filter
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

from bot.config import settings
from bot.database import repo
from bot.handlers.states import AddNote, AddStudents, RemoveStudent, DeleteNote
from bot.utils.parsing import parse_bulk

logger = logging.getLogger(__name__)


class IsAdmin(Filter):
    """Router-level filter: only admins pass."""
    async def __call__(self, message: Message) -> bool:
        return bool(message.from_user) and settings.is_admin(message.from_user.id)


router = Router(name="admin")
# Apply admin gate to every handler in this router
router.message.filter(IsAdmin())


# ─────────────────────────── Add / Replace Note ───────────────────────────


@router.message(Command("addnote"))
async def addnote_start(message: Message, state: FSMContext) -> None:
    await state.clear()
    await state.set_state(AddNote.waiting_serial)
    await message.answer(
        "📝 <b>Добавление конспекта</b>\n\n"
        "Шаг 1/3 — пришли <b>серийный номер</b> (число).\n"
        "Если конспект с таким номером уже есть — он будет заменён.\n\n"
        "Для отмены: /cancel"
    )


@router.message(AddNote.waiting_serial)
async def addnote_serial(message: Message, state: FSMContext) -> None:
    text = (message.text or "").strip()
    if not text.isdigit():
        await message.answer("Нужно <b>число</b>. Попробуй ещё раз или /cancel.")
        return
    serial = int(text)
    if serial < 1 or serial > 999_999:
        await message.answer("Номер вне допустимого диапазона. Попробуй ещё раз.")
        return

    existing = await repo.get_note(serial)
    await state.update_data(serial=serial)
    await state.set_state(AddNote.waiting_topic)

    if existing:
        await message.answer(
            f"⚠️ Конспект №{serial} уже существует: "
            f"<i>{html.escape(existing.topic)}</i>\n"
            f"Он будет <b>заменён</b>.\n\n"
            f"Шаг 2/3 — пришли <b>тему</b> конспекта."
        )
    else:
        await message.answer(f"Шаг 2/3 — пришли <b>тему</b> конспекта №{serial}.")


@router.message(AddNote.waiting_topic)
async def addnote_topic(message: Message, state: FSMContext) -> None:
    topic = (message.text or "").strip()
    if not topic:
        await message.answer("Тема не может быть пустой. Попробуй ещё раз или /cancel.")
        return
    if len(topic) > 250:
        await message.answer("Слишком длинная тема (максимум 250 символов).")
        return

    await state.update_data(topic=topic)
    await state.set_state(AddNote.waiting_pdf)
    await message.answer(
        f"Шаг 3/3 — пришли <b>PDF-файл</b> конспекта.\n\n"
        f"Тема: <i>{html.escape(topic)}</i>"
    )


@router.message(AddNote.waiting_pdf, F.document)
async def addnote_pdf(message: Message, state: FSMContext) -> None:
    doc = message.document
    # Accept .pdf strictly — preserves the "конспект-as-PDF" guarantee
    mime_ok = (doc.mime_type or "").lower() == "application/pdf"
    name_ok = (doc.file_name or "").lower().endswith(".pdf")
    if not (mime_ok or name_ok):
        await message.answer(
            "❗ Нужен <b>PDF-файл</b>. Пришли документ с расширением .pdf или /cancel."
        )
        return

    data = await state.get_data()
    serial = data["serial"]
    topic = data["topic"]

    result = await repo.upsert_note(
        serial=serial,
        topic=topic,
        file_id=doc.file_id,
        file_unique=doc.file_unique_id,
        file_name=doc.file_name,
        file_size=doc.file_size,
        added_by=message.from_user.id,
    )
    await state.clear()

    verb = "заменён" if result == "replaced" else "добавлен"
    icon = "🔁" if result == "replaced" else "✅"
    await message.answer(
        f"{icon} Конспект №<b>{serial}</b> {verb}.\n"
        f"Тема: <i>{html.escape(topic)}</i>"
    )


@router.message(AddNote.waiting_pdf)
async def addnote_pdf_wrong(message: Message) -> None:
    await message.answer("Жду <b>PDF-файл</b>. Или /cancel для отмены.")


# ─────────────────────────── Delete Note ───────────────────────────


@router.message(Command("delnote"))
async def delnote_start(message: Message, state: FSMContext, command: CommandObject) -> None:
    await state.clear()
    # Support both: /delnote 29 (one-shot) and /delnote (wizard)
    if command.args and command.args.strip().isdigit():
        await _do_delete_note(message, int(command.args.strip()))
        return
    await state.set_state(DeleteNote.waiting_serial)
    await message.answer("Какой номер конспекта удалить? Пришли число или /cancel.")


@router.message(DeleteNote.waiting_serial)
async def delnote_serial(message: Message, state: FSMContext) -> None:
    text = (message.text or "").strip()
    if not text.isdigit():
        await message.answer("Нужно число. Или /cancel.")
        return
    await state.clear()
    await _do_delete_note(message, int(text))


async def _do_delete_note(message: Message, serial: int) -> None:
    note = await repo.get_note(serial)
    if not note:
        await message.answer(f"Конспект №{serial} не найден.")
        return
    ok = await repo.delete_note(serial)
    if ok:
        await message.answer(
            f"🗑 Удалён конспект №<b>{serial}</b>: "
            f"<i>{html.escape(note.topic)}</i>"
        )
    else:
        await message.answer("Не удалось удалить. Попробуй ещё раз.")


# ─────────────────────────── List Notes ───────────────────────────


@router.message(Command("notes"))
async def list_notes_cmd(message: Message) -> None:
    notes = await repo.list_notes(limit=300)
    if not notes:
        await message.answer("Пока нет ни одного конспекта.")
        return

    # Chunk into messages of ≤4000 chars to fit Telegram's 4096 limit
    lines = ["<b>📚 Список конспектов:</b>", ""]
    for n in notes:
        lines.append(f"<b>{n.serial}.</b> {html.escape(n.topic)}")

    buf = ""
    for line in lines:
        if len(buf) + len(line) + 1 > 3800:
            await message.answer(buf)
            buf = line
        else:
            buf = f"{buf}\n{line}" if buf else line
    if buf:
        await message.answer(buf)


# ─────────────────────────── Add Student(s) ───────────────────────────


@router.message(Command("addstudent"))
async def addstudent_start(message: Message, state: FSMContext, command: CommandObject) -> None:
    await state.clear()
    # Inline mode: /addstudent @vasya @petya 12345
    if command.args:
        await _process_bulk_students(message, command.args)
        return

    await state.set_state(AddStudents.waiting_list)
    await message.answer(
        "👥 <b>Добавление учеников</b>\n\n"
        "Пришли одного или нескольких учеников. Можно сразу много, "
        "через пробел / запятую / новую строку:\n\n"
        "<code>@ivan_petrov\n@maria\n123456789</code>\n\n"
        "Принимаются <b>@username</b> и числовые <b>Telegram ID</b>.\n"
        "Для отмены: /cancel"
    )


@router.message(AddStudents.waiting_list)
async def addstudent_list(message: Message, state: FSMContext) -> None:
    await state.clear()
    await _process_bulk_students(message, message.text or "")


async def _process_bulk_students(message: Message, raw: str) -> None:
    parsed = parse_bulk(raw)
    if not parsed:
        await message.answer("Не нашёл ни одного валидного @username или ID.")
        return

    added, skipped, errors = [], [], []
    for p in parsed:
        if p.error:
            errors.append(f"• <code>{html.escape(p.raw)}</code> — {p.error}")
            continue
        created, msg = await repo.add_student(
            tg_id=p.tg_id,
            username=p.username,
            full_name=None,
            added_by=message.from_user.id,
        )
        label = f"@{p.username}" if p.username else str(p.tg_id)
        if created:
            added.append(f"• {html.escape(label)}")
        else:
            skipped.append(f"• {html.escape(label)} — {msg}")

    parts = []
    if added:
        parts.append(f"✅ <b>Добавлено ({len(added)}):</b>\n" + "\n".join(added))
    if skipped:
        parts.append(f"⏭ <b>Пропущено ({len(skipped)}):</b>\n" + "\n".join(skipped))
    if errors:
        parts.append(f"❌ <b>Ошибки ({len(errors)}):</b>\n" + "\n".join(errors))

    await message.answer("\n\n".join(parts) if parts else "Ничего не изменилось.")


# ─────────────────────────── Remove Student ───────────────────────────


@router.message(Command("delstudent"))
async def delstudent_start(message: Message, state: FSMContext, command: CommandObject) -> None:
    await state.clear()
    if command.args:
        await _process_delete_student(message, command.args.strip())
        return
    await state.set_state(RemoveStudent.waiting_identity)
    await message.answer(
        "Кого удалить? Пришли <b>@username</b> или <b>ID</b>.\n"
        "Для отмены: /cancel"
    )


@router.message(RemoveStudent.waiting_identity)
async def delstudent_identity(message: Message, state: FSMContext) -> None:
    await state.clear()
    await _process_delete_student(message, message.text or "")


async def _process_delete_student(message: Message, raw: str) -> None:
    parsed = parse_bulk(raw)
    if not parsed:
        await message.answer("Не понял, кого удалить.")
        return

    removed, missed = [], []
    for p in parsed:
        if p.error:
            missed.append(f"• <code>{html.escape(p.raw)}</code> — {p.error}")
            continue
        ok = False
        if p.tg_id is not None:
            ok = await repo.remove_student_by_tg_id(p.tg_id)
        elif p.username:
            ok = await repo.remove_student_by_username(p.username)
        label = f"@{p.username}" if p.username else str(p.tg_id)
        if ok:
            removed.append(f"• {html.escape(label)}")
        else:
            missed.append(f"• {html.escape(label)} — не найден")

    parts = []
    if removed:
        parts.append(f"🗑 <b>Удалено ({len(removed)}):</b>\n" + "\n".join(removed))
    if missed:
        parts.append(f"⚠️ <b>Не найдено ({len(missed)}):</b>\n" + "\n".join(missed))
    await message.answer("\n\n".join(parts))


# ─────────────────────────── List Students ───────────────────────────


@router.message(Command("students"))
async def list_students_cmd(message: Message) -> None:
    students = await repo.list_students()
    if not students:
        await message.answer("Пока нет ни одного ученика.")
        return

    lines = [f"<b>👥 Ученики ({len(students)}):</b>", ""]
    for s in students:
        if s.username:
            label = f"@{html.escape(s.username)}"
        else:
            label = f"ID <code>{s.tg_id}</code>"
        if s.tg_id and s.username:
            label += f" (<code>{s.tg_id}</code>)"
        lines.append(f"• {label}")

    buf = ""
    for line in lines:
        if len(buf) + len(line) + 1 > 3800:
            await message.answer(buf)
            buf = line
        else:
            buf = f"{buf}\n{line}" if buf else line
    if buf:
        await message.answer(buf)


# ─────────────────────────── Stats ───────────────────────────


@router.message(Command("stats"))
async def stats_cmd(message: Message) -> None:
    n_students = await repo.count_students()
    n_notes = await repo.count_notes()
    await message.answer(
        f"📊 <b>Статистика</b>\n\n"
        f"Учеников: <b>{n_students}</b>\n"
        f"Конспектов: <b>{n_notes}</b>"
    )
