"""FSM state groups for multi-step admin workflows."""
from aiogram.fsm.state import State, StatesGroup


class AddNote(StatesGroup):
    waiting_serial = State()
    waiting_topic = State()
    waiting_pdf = State()


class AddStudents(StatesGroup):
    waiting_list = State()


class RemoveStudent(StatesGroup):
    waiting_identity = State()


class DeleteNote(StatesGroup):
    waiting_serial = State()
