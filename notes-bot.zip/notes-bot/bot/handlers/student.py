"""Student-facing handler: receive a serial number, send the matching PDF."""
import logging

from aiogram import Router, F
from aiogram.types import Message

from bot.config import settings
from bot.database import repo

logger = logging.getLogger(__name__)

router = Router(name="student")


@router.message(F.text.regexp(r"^\s*\d{1,6}\s*$"))
async def send_note_by_serial(message: Message) -> None:
    user = message.from_user

    # Admins can also fetch notes
    if not settings.is_admin(user.id):
        if not await repo.is_student(tg_id=user.id, username=user.username):
            await message.answer("🔒 У вас нет доступа к боту.")
            return

    try:
        serial = int(message.text.strip())
    except ValueError:
        return

    note = await repo.get_note(serial)
    if not note:
        await message.answer(
            f"❌ Конспект №{serial} не найден.\n\n"
            f"Проверь номер или спроси у преподавателя."
        )
        return

    caption = f"📘 <b>№{note.serial}. {note.topic}</b>"
    try:
        await message.answer_document(
            document=note.file_id,
            caption=caption,
        )
    except Exception as e:
        # file_id occasionally expires; tell the user the truth instead of failing silently
        logger.exception("Failed to send document for serial=%s: %s", serial, e)
        await message.answer(
            "⚠️ Не удалось отправить файл. Сообщите администратору, "
            "что нужно перезалить конспект №%d." % serial
        )
