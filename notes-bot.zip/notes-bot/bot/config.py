"""Application configuration loaded from environment variables."""
import os
from dataclasses import dataclass, field
from typing import List


def _parse_admin_ids(raw: str) -> List[int]:
    if not raw:
        return []
    result = []
    for chunk in raw.replace(";", ",").split(","):
        chunk = chunk.strip()
        if chunk.isdigit():
            result.append(int(chunk))
    return result


def _require(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise RuntimeError(
            f"Environment variable {name} is not set. "
            f"Configure it in Railway Variables or your .env file."
        )
    return value


@dataclass(frozen=True)
class Settings:
    BOT_TOKEN: str = field(default_factory=lambda: _require("BOT_TOKEN"))
    DATABASE_URL: str = field(default_factory=lambda: _require("DATABASE_URL"))
    ADMIN_IDS: List[int] = field(
        default_factory=lambda: _parse_admin_ids(os.getenv("ADMIN_IDS", ""))
    )

    def is_admin(self, user_id: int) -> bool:
        return user_id in self.ADMIN_IDS


settings = Settings()

if not settings.ADMIN_IDS:
    raise RuntimeError(
        "ADMIN_IDS is empty. Set it as a comma-separated list of Telegram user IDs, "
        "e.g. ADMIN_IDS=123456789,987654321"
    )
