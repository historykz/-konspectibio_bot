# Notes Bot

Telegram-бот для рассылки конспектов по серийному номеру. Доступ — только у учеников, добавленных админом.

## Что умеет

**Ученик:**
- Отправляет число (например, `29`) — получает PDF-конспект с темой и номером

**Админ:**
- `/addnote` — добавить или **заменить** конспект (мастер: номер → тема → PDF)
- `/delnote 29` или `/delnote` — удалить конспект
- `/notes` — список всех конспектов
- `/addstudent` — добавить одного или **массово** (список @username и/или ID)
- `/delstudent` — удалить ученика
- `/students` — список учеников
- `/stats` — статистика
- `/cancel` — отменить текущее действие

Файлы хранятся как Telegram `file_id` (бесконечное бесплатное хранилище, мгновенная отдача). Метаданные — в PostgreSQL.

## Деплой на Railway

### 1. Подготовка
1. Создай бота у [@BotFather](https://t.me/BotFather) → получи `BOT_TOKEN`
2. Узнай свой Telegram ID у [@userinfobot](https://t.me/userinfobot) → это `ADMIN_IDS`
3. Залей этот проект в GitHub-репозиторий

### 2. Railway
1. Зайди на [railway.app](https://railway.app) → **New Project** → **Deploy from GitHub repo**
2. В этом же проекте: **+ New** → **Database** → **Add PostgreSQL**
3. Открой сервис бота → **Variables** → добавь:

   | Переменная | Значение |
   |---|---|
   | `BOT_TOKEN` | токен от BotFather |
   | `ADMIN_IDS` | твой ID (или несколько через запятую: `111,222`) |
   | `DATABASE_URL` | `${{Postgres.DATABASE_URL}}` (ссылка на сервис Postgres) |

4. Сервис задеплоится автоматически. Логи — во вкладке **Deployments**.

### 3. Локальный запуск (для разработки)

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # затем заполни значения
export $(grep -v '^#' .env | xargs) && python -m bot
```

## Структура

```
bot/
├── __main__.py           # точка входа
├── config.py             # конфиг из ENV
├── middlewares.py        # авто-привязка username ↔ tg_id
├── database/
│   ├── db.py             # пул соединений + миграции схемы
│   └── repo.py           # запросы (students, notes)
├── handlers/
│   ├── common.py         # /start, /help, /cancel
│   ├── student.py        # ученик присылает число → PDF
│   ├── admin.py          # все админские команды
│   └── states.py         # FSM-состояния
└── utils/
    └── parsing.py        # парсер массового ввода @user/ID
```

## Заметки

- **Замена конспекта** — повторно вызови `/addnote` с тем же номером. Старый file_id перезапишется.
- **Ученик по @username** — пока он не написал боту первое сообщение, у него нет `tg_id` в базе. При первом `/start` мидлварь сама привяжет ID к юзернейму.
- **Лимиты Telegram** — файлы до 50 МБ через ботов; обычно для PDF-конспектов с запасом.
